<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE tileset SYSTEM "http://mapeditor.org/dtd/1.0/map.dtd">
<tileset name="terrain-city" tilewidth="8" tileheight="8" spacing="4" margin="2" tilecount="320" columns="16">
 <image source="terrain-city.png" width="192" height="240"/>
</tileset>
